// ============================================
// THE VIDEO POOL - HEADER v5.5
// With SearchAutocomplete, LayoutPresetSelector,
// and updated navigation
// ============================================

import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Bell,
  Settings,
  HelpCircle,
  Menu,
  Plus,
  Music,
} from 'lucide-react';
import { clsx } from 'clsx';
import SearchAutocomplete from './SearchAutocomplete';
import LayoutPresetSelector from './LayoutPresetSelector';
import DownloadCounter from './DownloadCounter';
import { useAppStore } from '@/stores/appStore';
import { useUIStore } from '@/stores/uiStore';

export default function Header() {
  const {
    toggleSetBuilder,
    toggleRequestPanel,
    isSetBuilderOpen,
    setBuilderTracks,
  } = useAppStore();

  const { unreadCount } = useUIStore();

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const setTrackCount = setBuilderTracks.length;

  return (
    <header className="sticky top-0 z-100 flex items-center gap-6 h-[72px] px-6 bg-tvp-bg-secondary border-b border-tvp-border-subtle">
      {/* Logo */}
      <Link to="/" className="flex items-center flex-shrink-0 group">
        <img
          src="/The Video Pool Logo 2.0.png"
          alt="The Video Pool"
          className="h-9 w-auto animate-logo-glow group-hover:animate-none group-hover:drop-shadow-[0_0_15px_var(--accent-cyan-glow)] transition-all"
        />
      </Link>

      {/* Search */}
      <SearchAutocomplete />

      {/* Navigation Links */}
      <nav className="hidden md:flex items-center gap-0.5">
        <Link
          to="/"
          className={clsx(
            'px-3.5 py-2 rounded-lg text-sm font-medium',
            'text-tvp-text-secondary hover:bg-tvp-accent-cyan-subtle hover:text-tvp-text-primary',
            'transition-colors'
          )}
        >
          Browse
        </Link>
        <Link
          to="/library"
          className={clsx(
            'px-3.5 py-2 rounded-lg text-sm font-medium',
            'text-tvp-text-secondary hover:bg-tvp-accent-cyan-subtle hover:text-tvp-text-primary',
            'transition-colors'
          )}
        >
          Library
        </Link>
        <button
          onClick={toggleRequestPanel}
          className={clsx(
            'px-3.5 py-2 rounded-lg text-sm font-medium',
            'text-tvp-text-secondary hover:bg-tvp-accent-cyan-subtle hover:text-tvp-text-primary',
            'transition-colors'
          )}
        >
          Request
        </button>
      </nav>

      {/* Right Actions */}
      <div className="flex items-center gap-2.5 ml-auto">
        {/* Download Counter */}
        <div className="hidden sm:block">
          <DownloadCounter variant="compact" />
        </div>

        {/* Layout Preset */}
        <div className="hidden lg:block">
          <LayoutPresetSelector />
        </div>

        {/* Set Builder Toggle */}
        <button
          onClick={toggleSetBuilder}
          className={clsx(
            'relative flex items-center gap-2 px-3 py-2',
            'border rounded-lg text-sm font-medium',
            'transition-all duration-fast',
            isSetBuilderOpen
              ? 'bg-tvp-accent-cyan-subtle border-tvp-accent-cyan text-tvp-accent-cyan'
              : 'bg-transparent border-tvp-border-subtle text-tvp-text-secondary hover:border-tvp-accent-cyan hover:text-tvp-accent-cyan'
          )}
        >
          <Music className="w-4 h-4" />
          <span className="hidden sm:inline">Set Builder</span>
          {setTrackCount > 0 && (
            <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 flex items-center justify-center bg-tvp-accent-coral text-white text-[10px] font-bold rounded-full">
              {setTrackCount}
            </span>
          )}
        </button>

        {/* Help */}
        <button
          className={clsx(
            'w-[38px] h-[38px] flex items-center justify-center',
            'bg-transparent border border-tvp-border-subtle rounded-lg',
            'text-tvp-text-secondary',
            'hover:bg-tvp-accent-cyan-subtle hover:border-tvp-accent-cyan hover:text-tvp-accent-cyan',
            'transition-all duration-fast'
          )}
          title="Help & Support"
          aria-label="Help and support"
        >
          <HelpCircle className="w-[18px] h-[18px]" aria-hidden="true" />
        </button>

        {/* Notifications */}
        <button
          className={clsx(
            'relative w-[38px] h-[38px] flex items-center justify-center',
            'bg-transparent border border-tvp-border-subtle rounded-lg',
            'text-tvp-text-secondary',
            'hover:bg-tvp-accent-cyan-subtle hover:border-tvp-accent-cyan hover:text-tvp-accent-cyan',
            'transition-all duration-fast'
          )}
          title="Notifications"
          aria-label={unreadCount > 0 ? `Notifications, ${unreadCount} unread` : 'Notifications'}
        >
          <Bell className="w-[18px] h-[18px]" aria-hidden="true" />
          {unreadCount > 0 && (
            <span
              className="absolute -top-1 -right-1 min-w-[16px] h-[16px] px-1 flex items-center justify-center bg-tvp-accent-coral text-white text-[10px] font-bold rounded-full"
              aria-hidden="true"
            >
              {unreadCount}
            </span>
          )}
        </button>

        {/* Settings */}
        <Link
          to="/settings"
          className={clsx(
            'w-[38px] h-[38px] flex items-center justify-center',
            'bg-transparent border border-tvp-border-subtle rounded-lg',
            'text-tvp-text-secondary',
            'hover:bg-tvp-accent-cyan-subtle hover:border-tvp-accent-cyan hover:text-tvp-accent-cyan',
            'transition-all duration-fast'
          )}
          title="Settings"
          aria-label="Settings"
        >
          <Settings className="w-[18px] h-[18px]" aria-hidden="true" />
        </Link>

        {/* User Avatar */}
        <button
          className={clsx(
            'w-[38px] h-[38px] flex items-center justify-center',
            'bg-tvp-accent-cyan rounded-full',
            'text-black font-semibold text-[13px]',
            'hover:shadow-[0_0_15px_var(--accent-cyan-glow)]',
            'transition-shadow'
          )}
          title="Account"
          aria-label="Your account"
        >
          DJ
        </button>

        {/* Mobile Menu Toggle */}
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className={clsx(
            'md:hidden w-[38px] h-[38px] flex items-center justify-center',
            'bg-transparent border border-tvp-border-subtle rounded-lg',
            'text-tvp-text-secondary',
            'hover:bg-tvp-accent-cyan-subtle hover:border-tvp-accent-cyan hover:text-tvp-accent-cyan',
            'transition-all duration-fast'
          )}
          aria-label={isMobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
          aria-expanded={isMobileMenuOpen}
        >
          <Menu className="w-[18px] h-[18px]" aria-hidden="true" />
        </button>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="absolute top-full left-0 right-0 bg-tvp-bg-secondary border-b border-tvp-border-subtle p-4 md:hidden animate-fade-in">
          <nav className="flex flex-col gap-2">
            <Link
              to="/"
              className="px-4 py-3 rounded-lg text-tvp-text-secondary hover:bg-tvp-bg-tertiary"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Browse
            </Link>
            <Link
              to="/library"
              className="px-4 py-3 rounded-lg text-tvp-text-secondary hover:bg-tvp-bg-tertiary"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Library
            </Link>
            <button
              onClick={() => {
                toggleRequestPanel();
                setIsMobileMenuOpen(false);
              }}
              className="px-4 py-3 rounded-lg text-tvp-text-secondary hover:bg-tvp-bg-tertiary text-left"
            >
              Request
            </button>
          </nav>
        </div>
      )}
    </header>
  );
}
