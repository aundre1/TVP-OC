// ============================================
// THE VIDEO POOL - SET BUILDER PANEL v5.5
// Right slide-out panel with drag-drop and
// smart recommendations (BPM/Key/Genre algorithm)
// ============================================

import { useState } from 'react';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import {
  X,
  GripVertical,
  Play,
  Trash2,
  Download,
  Plus,
  Sparkles,
  Music,
  Clock,
  Zap,
  Share2,
  Save,
  Info,
  Check,
} from 'lucide-react';
import { clsx } from 'clsx';
import { useAppStore } from '@/stores/appStore';
import { getAllTracks } from '@/data/tracks';
import { SetBuilderTrack, Track } from '@/types';
import ShareSetModal from './ShareSetModal';

// Sortable Track Item
function SortableTrackItem({
  track,
  index,
  onRemove,
  onPlay,
}: {
  track: SetBuilderTrack;
  index: number;
  onRemove: () => void;
  onPlay: () => void;
}) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: track.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={clsx(
        'flex items-center gap-3 p-3 rounded-lg',
        'bg-tvp-bg-tertiary border border-tvp-border-subtle',
        'transition-all duration-fast',
        isDragging && 'opacity-50 shadow-elevated z-50'
      )}
    >
      {/* Drag Handle */}
      <button
        {...attributes}
        {...listeners}
        className="cursor-grab active:cursor-grabbing text-tvp-text-muted hover:text-tvp-text-secondary"
      >
        <GripVertical className="w-4 h-4" />
      </button>

      {/* Track Number */}
      <span className="w-6 text-center text-xs font-mono text-tvp-text-muted">
        {index + 1}
      </span>

      {/* Track Info */}
      <div className="flex-1 min-w-0">
        <div className="text-sm font-medium text-tvp-text-primary truncate">
          {track.title}
        </div>
        <div className="text-xs text-tvp-text-muted truncate">{track.artist}</div>
      </div>

      {/* BPM/Key */}
      <div className="flex items-center gap-2 text-xs font-mono text-tvp-text-muted">
        <span>{track.bpm}</span>
        <span className="text-tvp-accent-cyan">{track.key}</span>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-1">
        <button
          onClick={onPlay}
          className="p-1.5 rounded hover:bg-tvp-bg-elevated text-tvp-text-muted hover:text-tvp-accent-cyan transition-colors"
          title="Preview"
        >
          <Play className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={onRemove}
          className="p-1.5 rounded hover:bg-tvp-bg-elevated text-tvp-text-muted hover:text-tvp-status-error transition-colors"
          title="Remove"
        >
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
}

// Recommendation Item with Transparency
function RecommendationItem({
  track,
  score,
  reasons,
  onAdd,
}: {
  track: Track;
  score: number;
  reasons: string[];
  onAdd: () => void;
}) {
  const [showDetails, setShowDetails] = useState(false);

  // Score breakdown for tooltip
  const getScoreLabel = (s: number) => {
    if (s >= 75) return 'Excellent';
    if (s >= 60) return 'Great';
    if (s >= 40) return 'Good';
    if (s >= 20) return 'Fair';
    return 'Low';
  };

  return (
    <div className="group">
      <div
        className={clsx(
          'flex items-center gap-3 p-3 rounded-lg',
          'bg-tvp-bg-tertiary/50 border border-tvp-border-subtle',
          'hover:border-tvp-accent-cyan transition-colors',
          showDetails && 'border-tvp-accent-cyan/50'
        )}
      >
        {/* Score Indicator with Label */}
        <button
          onClick={() => setShowDetails(!showDetails)}
          className={clsx(
            'relative w-10 h-10 rounded-full flex flex-col items-center justify-center',
            'text-xs font-bold transition-transform hover:scale-105',
            score >= 60 ? 'bg-tvp-status-success/20 text-tvp-status-success' :
            score >= 40 ? 'bg-tvp-status-warning/20 text-tvp-status-warning' :
            'bg-tvp-bg-elevated text-tvp-text-muted'
          )}
          title={`Match Score: ${score} (${getScoreLabel(score)})`}
        >
          <span className="text-sm font-bold">{score}</span>
          <Info className="w-3 h-3 absolute -bottom-0.5 -right-0.5 opacity-0 group-hover:opacity-100 transition-opacity" />
        </button>

        {/* Track Info */}
        <div className="flex-1 min-w-0">
          <div className="text-sm font-medium text-tvp-text-primary truncate">
            {track.title}
          </div>
          <div className="flex items-center gap-2 text-xs text-tvp-text-muted">
            <span className="truncate">{track.artist}</span>
            <span className="text-tvp-border-default">•</span>
            <span className="font-mono">{track.bpm} BPM</span>
            <span className="text-tvp-border-default">•</span>
            <span className="font-mono text-tvp-accent-cyan">{track.key}</span>
          </div>
          <div className="flex flex-wrap gap-1 mt-1.5">
            {reasons.map((reason, i) => {
              // Parse reason to show type badge
              const [type, detail] = reason.split(':').map(s => s.trim());
              const isActive = reason.toLowerCase().includes('harmonic') ||
                               reason.toLowerCase().includes('same') ||
                               parseInt(detail?.match(/\d+/)?.[0] || '99') <= 8;
              return (
                <span
                  key={i}
                  className={clsx(
                    'text-[10px] px-1.5 py-0.5 rounded',
                    isActive
                      ? 'bg-tvp-accent-cyan/20 text-tvp-accent-cyan'
                      : 'bg-tvp-bg-elevated text-tvp-text-muted'
                  )}
                  title={reason}
                >
                  {type}
                </span>
              );
            })}
          </div>
        </div>

        {/* Add Button */}
        <button
          onClick={onAdd}
          className={clsx(
            'p-2 rounded-lg',
            'bg-tvp-accent-cyan text-black',
            'hover:bg-tvp-accent-cyan-hover transition-colors'
          )}
          title="Add to set"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>

      {/* Expanded Details Panel */}
      {showDetails && (
        <div className="mt-1 ml-12 p-2.5 bg-tvp-bg-elevated rounded-lg border border-tvp-border-subtle">
          <div className="flex items-center gap-2 mb-2 text-xs font-semibold text-tvp-text-secondary">
            <Sparkles className="w-3 h-3 text-tvp-accent-cyan" />
            Why this track?
          </div>
          <ul className="space-y-1">
            {reasons.map((reason, i) => (
              <li key={i} className="flex items-start gap-2 text-xs text-tvp-text-muted">
                <Check className="w-3 h-3 text-tvp-status-success flex-shrink-0 mt-0.5" />
                <span>{reason}</span>
              </li>
            ))}
          </ul>
          <div className="mt-2 pt-2 border-t border-tvp-border-subtle flex justify-between items-center text-[10px] text-tvp-text-muted">
            <span>Match Quality: {getScoreLabel(score)}</span>
            <span className="font-mono">{score}/100</span>
          </div>
        </div>
      )}
    </div>
  );
}

// Main Set Builder Panel
export default function SetBuilder() {
  const {
    isSetBuilderOpen,
    closeSetBuilder,
    setBuilderTracks,
    removeFromSet,
    reorderSet,
    clearSet,
    getSetRecommendations,
    addToSet,
    openPreviewModal,
    showToast,
    openScoringModal,
  } = useAppStore();

  const [showRecommendations, setShowRecommendations] = useState(true);
  const [showShareModal, setShowShareModal] = useState(false);
  const [setName, setSetName] = useState('My DJ Set');
  const [isEditingName, setIsEditingName] = useState(false);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      const oldIndex = setBuilderTracks.findIndex((t) => t.id === active.id);
      const newIndex = setBuilderTracks.findIndex((t) => t.id === over.id);
      reorderSet(oldIndex, newIndex);
    }
  };

  const recommendations = getSetRecommendations(getAllTracks(), 5);

  const totalDuration = setBuilderTracks.reduce((acc, track) => {
    if (typeof track.duration === 'number') return acc + track.duration;
    const parts = track.duration.split(':').map(Number);
    if (parts.length === 2) return acc + parts[0] * 60 + parts[1];
    return acc + (parseInt(track.duration, 10) || 0);
  }, 0);

  const formatDuration = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    if (hrs > 0) return `${hrs}h ${mins}m`;
    return `${mins}m`;
  };

  const handleDownloadSet = () => {
    showToast('info', `Downloading ${setBuilderTracks.length} tracks...`);
  };

  if (!isSetBuilderOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-400 md:hidden"
        onClick={closeSetBuilder}
      />

      {/* Panel */}
      <div
        className={clsx(
          'fixed top-[72px] right-0 bottom-0 w-[400px] max-w-full',
          'bg-tvp-bg-secondary border-l border-tvp-border-subtle',
          'z-400 flex flex-col',
          'transform transition-transform duration-slow',
          isSetBuilderOpen ? 'translate-x-0' : 'translate-x-full',
          // Mobile: bottom sheet style
          'md:top-[72px] max-md:top-auto max-md:bottom-0 max-md:left-0 max-md:right-0',
          'max-md:w-full max-md:h-[70vh] max-md:rounded-t-2xl max-md:border-t'
        )}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-tvp-border-subtle">
          <div className="flex-1 min-w-0">
            {isEditingName ? (
              <input
                type="text"
                value={setName}
                onChange={(e) => setSetName(e.target.value)}
                onBlur={() => setIsEditingName(false)}
                onKeyDown={(e) => e.key === 'Enter' && setIsEditingName(false)}
                autoFocus
                className="text-lg font-bold bg-transparent border-b border-tvp-accent-cyan outline-none w-full"
              />
            ) : (
              <h2
                onClick={() => setIsEditingName(true)}
                className="text-lg font-bold flex items-center gap-2 cursor-pointer hover:text-tvp-accent-cyan transition-colors"
              >
                <Music className="w-5 h-5 text-tvp-accent-cyan" />
                {setName}
              </h2>
            )}
            <div className="flex items-center gap-4 mt-1 text-xs text-tvp-text-muted">
              <span>{setBuilderTracks.length} tracks</span>
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {formatDuration(totalDuration)}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {setBuilderTracks.length > 0 && (
              <button
                onClick={() => setShowShareModal(true)}
                className="p-2 rounded-lg bg-tvp-bg-tertiary hover:bg-tvp-accent-cyan hover:text-black text-tvp-text-secondary transition-colors"
                title="Share Set"
              >
                <Share2 className="w-5 h-5" />
              </button>
            )}
            <button
              onClick={closeSetBuilder}
              className="p-2 rounded-lg bg-tvp-bg-tertiary hover:bg-tvp-bg-elevated text-tvp-text-secondary transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Track List */}
        <div className="flex-1 overflow-y-auto p-4">
          {setBuilderTracks.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center px-8">
              <div className="w-16 h-16 rounded-full bg-tvp-bg-tertiary flex items-center justify-center mb-4">
                <Music className="w-8 h-8 text-tvp-text-muted" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Your set is empty</h3>
              <p className="text-sm text-tvp-text-muted">
                Add tracks to build your perfect DJ set. Use the <kbd className="kbd mx-1">S</kbd> key
                or click the + button on any track.
              </p>
            </div>
          ) : (
            <DndContext
              sensors={sensors}
              collisionDetection={closestCenter}
              onDragEnd={handleDragEnd}
            >
              <SortableContext
                items={setBuilderTracks.map((t) => t.id)}
                strategy={verticalListSortingStrategy}
              >
                <div className="space-y-2">
                  {setBuilderTracks.map((track, index) => (
                    <SortableTrackItem
                      key={track.id}
                      track={track}
                      index={index}
                      onRemove={() => removeFromSet(track.id)}
                      onPlay={() => openPreviewModal(track.id)}
                    />
                  ))}
                </div>
              </SortableContext>
            </DndContext>
          )}

          {/* Recommendations Section */}
          {setBuilderTracks.length > 0 && recommendations.length > 0 && (
            <div className="mt-6">
              {/* Header Row */}
              <div className="flex items-center justify-between mb-3">
                <button
                  onClick={() => setShowRecommendations(!showRecommendations)}
                  className="flex items-center gap-2 text-sm font-semibold text-tvp-accent-cyan"
                >
                  <Sparkles className="w-4 h-4" />
                  Recommended Next
                  <Zap className="w-3 h-3" />
                </button>

                <div className="flex items-center gap-3">
                  {/* How scoring works link */}
                  <button
                    onClick={openScoringModal}
                    className="text-xs text-tvp-text-muted hover:text-tvp-accent-cyan hover:underline transition-colors"
                  >
                    How scoring works
                  </button>

                  {/* Bulk Add Button */}
                  <button
                    onClick={() => {
                      const tracksToAdd = recommendations.slice(0, 5);
                      tracksToAdd.forEach(rec => addToSet(rec.track));
                      showToast('success', `Added ${tracksToAdd.length} tracks to your set`);
                    }}
                    className="flex items-center gap-1 text-xs text-tvp-accent-cyan hover:underline transition-colors"
                  >
                    <Plus className="w-3 h-3" />
                    Add Top {Math.min(5, recommendations.length)}
                  </button>
                </div>
              </div>

              {showRecommendations && (
                <div className="space-y-2">
                  {recommendations.map(({ track, score, reasons }) => (
                    <RecommendationItem
                      key={track.id}
                      track={track}
                      score={score}
                      reasons={reasons}
                      onAdd={() => addToSet(track)}
                    />
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer Actions */}
        {setBuilderTracks.length > 0 && (
          <div className="px-4 py-4 border-t border-tvp-border-subtle">
            <div className="flex gap-3">
              <button
                onClick={clearSet}
                className={clsx(
                  'flex-1 flex items-center justify-center gap-2 py-3 rounded-lg',
                  'bg-tvp-bg-tertiary border border-tvp-border-subtle',
                  'text-tvp-text-secondary text-sm font-medium',
                  'hover:border-tvp-status-error hover:text-tvp-status-error transition-colors'
                )}
              >
                <Trash2 className="w-4 h-4" />
                Clear
              </button>
              <button
                onClick={handleDownloadSet}
                className={clsx(
                  'flex-[2] flex items-center justify-center gap-2 py-3 rounded-lg',
                  'bg-tvp-accent-cyan text-black text-sm font-semibold',
                  'hover:bg-tvp-accent-cyan-hover transition-colors'
                )}
              >
                <Download className="w-4 h-4" />
                Download Set
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Share Modal */}
      <ShareSetModal
        isOpen={showShareModal}
        onClose={() => setShowShareModal(false)}
        tracks={setBuilderTracks}
        setName={setName}
      />
    </>
  );
}
