// ============================================
// THE VIDEO POOL - GENRE NAVIGATION v5.5
// Genre chips with mega menu dropdowns
// Click-to-open (not hover) per Council decision
// ============================================

import { useState, useRef, useEffect } from 'react';
import {
  useFloating,
  autoUpdate,
  offset,
  flip,
  shift,
  useClick,
  useDismiss,
  useInteractions,
  FloatingPortal,
} from '@floating-ui/react';
import { ChevronDown, Settings } from 'lucide-react';
import { clsx } from 'clsx';
import { genres } from '@/data/genres';
import { useAppStore } from '@/stores/appStore';
import { Genre, Subgenre } from '@/types';

// Single Genre Chip with Mega Menu
function GenreChip({ genre }: { genre: Genre }) {
  const [isOpen, setIsOpen] = useState(false);
  const { activeGenre, activeSubgenre, setActiveGenre, setActiveSubgenre } = useAppStore();

  const isActive = activeGenre === genre.id;

  const { refs, floatingStyles, context } = useFloating({
    open: isOpen,
    onOpenChange: setIsOpen,
    middleware: [offset(8), flip(), shift({ padding: 8 })],
    whileElementsMounted: autoUpdate,
    placement: 'bottom-start',
  });

  const click = useClick(context);
  const dismiss = useDismiss(context);

  const { getReferenceProps, getFloatingProps } = useInteractions([click, dismiss]);

  const handleGenreClick = () => {
    if (isActive) {
      setActiveGenre(null);
    } else {
      setActiveGenre(genre.id);
    }
    setIsOpen(false);
  };

  const handleSubgenreClick = (subgenre: Subgenre) => {
    setActiveGenre(genre.id);
    setActiveSubgenre(subgenre.id);
    setIsOpen(false);
  };

  return (
    <>
      <button
        ref={refs.setReference}
        {...getReferenceProps()}
        className={clsx(
          'relative flex items-center gap-1 px-4 py-2',
          'bg-tvp-bg-tertiary border border-tvp-border-subtle rounded-[20px]',
          'text-tvp-text-secondary text-[13px] font-medium',
          'whitespace-nowrap cursor-pointer',
          'transition-all duration-fast touch-target',
          'hover:border-tvp-accent-cyan hover:text-tvp-text-primary',
          isActive && 'bg-tvp-accent-cyan border-tvp-accent-cyan text-black',
          isOpen && 'z-200'
        )}
      >
        <span>{genre.icon}</span>
        <span>{genre.name}</span>
        <ChevronDown
          className={clsx(
            'w-3 h-3 ml-0.5 transition-transform duration-fast',
            isOpen && 'rotate-180'
          )}
        />
      </button>

      {/* Mega Menu */}
      {isOpen && (
        <FloatingPortal>
          <div
            ref={refs.setFloating}
            style={floatingStyles}
            {...getFloatingProps()}
            className={clsx(
              'w-[420px] p-4',
              'bg-tvp-bg-secondary border border-tvp-border-default rounded-xl',
              'shadow-elevated z-1000',
              'animate-fade-in'
            )}
          >
            {/* Genre Header */}
            <div className="flex items-center justify-between mb-3">
              <button
                onClick={handleGenreClick}
                className={clsx(
                  'flex items-center gap-2 px-3 py-1.5 rounded-lg',
                  'text-sm font-semibold',
                  'hover:bg-tvp-accent-cyan-subtle hover:text-tvp-accent-cyan',
                  'transition-colors duration-fast'
                )}
              >
                <span>{genre.icon}</span>
                <span>All {genre.name}</span>
              </button>
              <span className="text-xs text-tvp-text-muted">
                {genre.subgenres.reduce((sum, s) => sum + s.count, 0).toLocaleString()} videos
              </span>
            </div>

            {/* Subgenres Grid */}
            <div className="mb-3">
              <div className="text-[11px] font-semibold text-tvp-text-muted uppercase tracking-wider mb-2">
                Subgenres
              </div>
              <div className="flex flex-wrap gap-1.5">
                {genre.subgenres.map((subgenre) => (
                  <button
                    key={subgenre.id}
                    onClick={() => handleSubgenreClick(subgenre)}
                    className={clsx(
                      'px-3 py-1.5 rounded-md',
                      'bg-tvp-bg-tertiary text-tvp-text-secondary text-xs',
                      'hover:bg-tvp-accent-cyan-subtle hover:text-tvp-accent-cyan',
                      'transition-colors duration-fast',
                      activeSubgenre === subgenre.id &&
                        'bg-tvp-accent-cyan-subtle text-tvp-accent-cyan'
                    )}
                  >
                    {subgenre.name}
                    <span className="ml-1.5 text-tvp-text-muted">
                      ({subgenre.count.toLocaleString()})
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </FloatingPortal>
      )}
    </>
  );
}

// Main Genre Navigation Component
export default function GenreNav() {
  const scrollRef = useRef<HTMLDivElement>(null);
  const { activeGenre, clearGenreFilter } = useAppStore();

  return (
    <nav className="sticky top-[72px] z-90 bg-tvp-bg-secondary border-b border-tvp-border-subtle px-6">
      <div
        ref={scrollRef}
        className={clsx(
          'flex items-center gap-2 py-2.5',
          'overflow-x-auto overflow-y-visible',
          'hide-scrollbar genre-nav-scroll'
        )}
      >
        {/* All Genres Chip */}
        <button
          onClick={clearGenreFilter}
          className={clsx(
            'flex items-center px-4 py-2',
            'bg-tvp-bg-tertiary border border-tvp-border-subtle rounded-[20px]',
            'text-tvp-text-secondary text-[13px] font-medium',
            'whitespace-nowrap cursor-pointer',
            'transition-all duration-fast touch-target',
            'hover:border-tvp-accent-cyan hover:text-tvp-text-primary',
            !activeGenre && 'bg-tvp-accent-cyan border-tvp-accent-cyan text-black'
          )}
        >
          All
        </button>

        {/* Genre Chips */}
        {genres.map((genre) => (
          <GenreChip key={genre.id} genre={genre} />
        ))}

        {/* Customize Button */}
        <button
          className={clsx(
            'flex items-center gap-1 px-3 py-2',
            'bg-transparent border border-dashed border-tvp-border-default rounded-[20px]',
            'text-tvp-text-muted text-xs',
            'cursor-pointer transition-colors duration-fast',
            'hover:border-tvp-accent-cyan hover:text-tvp-accent-cyan'
          )}
        >
          <Settings className="w-3 h-3" />
          <span>Customize</span>
        </button>
      </div>
    </nav>
  );
}
