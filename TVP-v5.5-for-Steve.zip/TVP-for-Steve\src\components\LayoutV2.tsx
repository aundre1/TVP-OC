// ============================================
// THE VIDEO POOL - MAIN LAYOUT v5.5
// With all panels, modals, and keyboard shortcuts
// ============================================

import { Outlet } from 'react-router-dom';
import { useEffect } from 'react';

// Layout components
import HeaderV2 from './HeaderV2';
import GenreNav from './GenreNav';
import Toolbar from './Toolbar';

// Panels
import SetBuilder from './SetBuilder';
import RecentDownloadsPanel from './RecentDownloadsPanel';
import RequestPanel from './RequestPanel';
import ShortcutsPanel, { ShortcutFeedback } from './ShortcutsPanel';

// Modals
import PreviewModalV2 from './PreviewModalV2';
import ToastContainer from './Toast';
import DownloadLimitModal from './DownloadLimitModal';
import DownloadQualityModalWrapper from './DownloadQualityModalWrapper';
import BatchDownloadModalWrapper from './BatchDownloadModalWrapper';
import ScoringExplanationModal from './ScoringExplanationModal';
import DuplicateWarningModal from './DuplicateWarningModal';

// Trial components
import FreeTrialBanner from './FreeTrialBanner';
import TrialExpiredModal from './TrialExpiredModal';

// Hooks
import { useKeyboardShortcuts } from '@/hooks/useKeyboardShortcuts';

export default function Layout() {
  // Initialize keyboard shortcuts
  useKeyboardShortcuts();

  return (
    <div className="min-h-screen bg-tvp-bg-primary">
      {/* Header */}
      <HeaderV2 />

      {/* Free Trial Banner */}
      <FreeTrialBanner />

      {/* Genre Navigation */}
      <GenreNav />

      {/* Toolbar */}
      <Toolbar />

      {/* Main Content */}
      <main className="pb-32">
        <Outlet />
      </main>

      {/* Panels */}
      <SetBuilder />
      <RecentDownloadsPanel />
      <RequestPanel />
      <ShortcutsPanel />

      {/* Modals */}
      <PreviewModalV2 />
      <TrialExpiredModal />
      <DownloadLimitModal />
      <DownloadQualityModalWrapper />
      <BatchDownloadModalWrapper />
      <ScoringExplanationModal />
      <DuplicateWarningModal />

      {/* Toast Notifications */}
      <ToastContainer />

      {/* Keyboard Shortcut Feedback */}
      <ShortcutFeedback />
    </div>
  );
}
