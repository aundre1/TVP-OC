// ============================================
// THE VIDEO POOL - VIDEO CARD v5.5
// With quality colors, badges, softer hover effects
// ============================================

import { useState, useRef, useEffect } from 'react';
import { Play, Plus, Download, Check, Lock, Heart, MoreHorizontal, Share2, FolderPlus, Eye, Flag, Sparkles } from 'lucide-react';
import { clsx } from 'clsx';
import { Track, VideoQuality } from '@/types';
import { useAppStore } from '@/stores/appStore';
import { useDownloadWithLimitCheck } from '@/hooks';

// Format download count (1.2K, 15K, etc.)
function formatDownloads(count: number): string {
  if (count >= 1000000) return `${(count / 1000000).toFixed(1)}M`;
  if (count >= 1000) return `${(count / 1000).toFixed(1)}K`;
  return count.toString();
}

interface VideoCardProps {
  track: Track;
  showCheckbox?: boolean;
}

// Quality badge component
function QualityBadge({ quality }: { quality: VideoQuality }) {
  const qualityClasses: Record<VideoQuality, string> = {
    '4K': 'quality-4k',
    '1080p': 'quality-1080p',
    '720p': 'quality-720p',
    '480p': 'quality-480p',
    '320p': 'quality-320p',
  };

  return (
    <span
      className={clsx(
        'absolute bottom-2 left-2 px-2 py-0.5 rounded text-[10px] font-bold min-w-[36px] text-center',
        qualityClasses[quality]
      )}
    >
      {quality}
    </span>
  );
}

export default function VideoCard({ track, showCheckbox = true }: VideoCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [isDownloadHovered, setIsDownloadHovered] = useState(false);
  const [isFavorite, setIsFavorite] = useState(track.isFavorite ?? false);
  const [showContextMenu, setShowContextMenu] = useState(false);
  const contextMenuRef = useRef<HTMLDivElement>(null);

  const {
    selectedTrackIds,
    toggleTrackSelection,
    openPreviewModal,
    addToSet,
    showToast,
    openDownloadQualityModal,
  } = useAppStore();

  // Close context menu on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (contextMenuRef.current && !contextMenuRef.current.contains(event.target as Node)) {
        setShowContextMenu(false);
      }
    }
    if (showContextMenu) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }
  }, [showContextMenu]);

  const {
    canDownload,
    isAtLimit,
    isNearLimit,
    isDownloading,
    openDownloadLimitModal,
  } = useDownloadWithLimitCheck();

  const isSelected = selectedTrackIds.has(track.id);

  const handleCheckboxClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleTrackSelection(track.id);
  };

  const handleAddToSet = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToSet(track);
  };

  const handleDownload = (e: React.MouseEvent) => {
    e.stopPropagation();

    // Check if at download limit
    if (isAtLimit || !canDownload) {
      openDownloadLimitModal();
      return;
    }

    // Open quality selection modal
    openDownloadQualityModal(track.id);
  };

  const handleCardClick = () => {
    openPreviewModal(track.id);
  };

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsFavorite(!isFavorite);
    showToast('success', isFavorite ? 'Removed from favorites' : 'Added to favorites');
  };

  const handleContextMenuClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowContextMenu(!showContextMenu);
  };

  const handleAddToCrate = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowContextMenu(false);
    showToast('info', 'Add to Crate - Coming soon');
  };

  const handleShare = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowContextMenu(false);
    showToast('info', 'Share link copied!');
  };

  const handleViewDetails = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowContextMenu(false);
    openPreviewModal(track.id);
  };

  const handleMoreLikeThis = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowContextMenu(false);
    // TODO: Trigger AI recommendation query with this track as seed
    showToast('info', `Finding tracks similar to "${track.title}"...`);
  };

  return (
    <div
      onClick={handleCardClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className={clsx(
        'relative bg-tvp-bg-secondary border border-tvp-border-subtle rounded-xl overflow-hidden',
        'cursor-pointer card-hover',
        isSelected && 'border-tvp-accent-cyan shadow-[0_0_0_2px_var(--accent-cyan)]'
      )}
    >
      {/* Checkbox */}
      {showCheckbox && (
        <button
          onClick={handleCheckboxClick}
          className={clsx(
            'absolute top-3 left-3 z-10 w-6 h-6',
            'bg-tvp-bg-secondary border-2 border-tvp-border-default rounded-md',
            'flex items-center justify-center',
            'transition-all duration-fast',
            (isHovered || isSelected) ? 'opacity-100' : 'opacity-0',
            isSelected && 'bg-tvp-accent-cyan border-tvp-accent-cyan'
          )}
        >
          {isSelected && <Check className="w-3.5 h-3.5 text-black" />}
        </button>
      )}

      {/* Thumbnail */}
      <div
        className={clsx(
          'relative overflow-hidden bg-tvp-bg-tertiary',
          track.aspect === '4:3' ? 'aspect-[4/3]' : 'aspect-video'
        )}
      >
        <img
          src={track.thumbnailUrl || `https://picsum.photos/320/180?random=${track.id}`}
          alt={track.title}
          className="w-full h-full object-cover transition-transform duration-400 ease-out group-hover:scale-105"
          style={{ transform: isHovered ? 'scale(1.05)' : 'scale(1)' }}
        />

        {/* Overlay */}
        <div
          className={clsx(
            'absolute inset-0',
            'bg-gradient-to-t from-black/80 via-transparent to-transparent',
            'flex items-center justify-center',
            'transition-opacity duration-normal',
            isHovered ? 'opacity-100' : 'opacity-0'
          )}
        >
          {/* Play Button */}
          <button
            className={clsx(
              'w-13 h-13 rounded-full',
              'bg-tvp-accent-cyan flex items-center justify-center',
              'transition-all duration-normal',
              isHovered ? 'scale-100 opacity-100' : 'scale-80 opacity-0'
            )}
          >
            <Play className="w-5 h-5 text-black ml-0.5" fill="black" />
          </button>
        </div>

        {/* Badges - NEW, HOT, EXCLUSIVE */}
        <div className="absolute top-2 left-10 flex gap-1.5">
          {track.isExclusive && (
            <span className="badge badge--exclusive px-1.5 py-0.5 text-[10px] font-bold bg-gradient-to-r from-yellow-500 to-amber-400 text-black rounded shadow-sm">
              EXCLUSIVE
            </span>
          )}
          {track.isNew && (
            <span className="badge badge--new px-1.5 py-0.5 text-[10px] font-bold bg-tvp-accent-coral text-white rounded">
              NEW
            </span>
          )}
          {track.isHot && (
            <span className="badge badge--hot px-1.5 py-0.5 text-[10px] font-bold bg-gradient-to-r from-tvp-accent-coral to-tvp-status-warning text-white rounded">
              HOT
            </span>
          )}
        </div>

        {/* Favorite Heart Button - Top Right */}
        <button
          onClick={handleFavoriteClick}
          className={clsx(
            'absolute top-2 right-2 p-1.5 rounded-lg',
            'transition-all duration-fast z-10',
            isFavorite
              ? 'bg-tvp-accent-coral/90 text-white'
              : 'bg-black/50 text-white/70 hover:text-white hover:bg-black/70',
            (isHovered || isFavorite) ? 'opacity-100' : 'opacity-0'
          )}
          title={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
        >
          <Heart className="w-4 h-4" fill={isFavorite ? 'currentColor' : 'none'} />
        </button>

        {/* Quality Badge */}
        <QualityBadge quality={track.quality} />

        {/* Duration */}
        <span className="absolute bottom-2 right-2 px-1.5 py-0.5 bg-black/80 text-white text-[11px] font-mono rounded">
          {track.duration}
        </span>
      </div>

      {/* Content - v5.5 Layout: Artist | Title | Label inline */}
      <div className="p-3.5">
        {/* Artist | Title | Label (all inline) */}
        <div className="flex items-center gap-1.5 mb-1.5 text-[13px] min-w-0">
          <span className="text-tvp-text-secondary flex-shrink-0 truncate max-w-[35%]">
            {track.artist}
          </span>
          <span className="text-tvp-border-subtle flex-shrink-0">|</span>
          <h3 className="font-semibold text-tvp-text-primary truncate">
            {track.title}
          </h3>
          {track.label && (
            <>
              <span className="text-tvp-border-subtle flex-shrink-0">|</span>
              <span className="text-tvp-text-muted truncate text-[11px]">
                {track.label}
              </span>
            </>
          )}
        </div>

        {/* Metadata (Monospace) - includes download count */}
        <div className="flex items-center gap-2 font-mono text-[11px] text-tvp-text-muted mb-3">
          <span>{track.bpm} BPM</span>
          <span>•</span>
          <span className="text-tvp-accent-cyan">{track.key}</span>
          {track.downloads !== undefined && track.downloads > 0 && (
            <>
              <span>•</span>
              <span className="flex items-center gap-0.5">
                <Download className="w-3 h-3" />
                {formatDownloads(track.downloads)}
              </span>
            </>
          )}
        </div>

        {/* Actions */}
        <div className="flex gap-2">
          <button
            onClick={handleAddToSet}
            className={clsx(
              'flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg',
              'bg-tvp-bg-tertiary border border-tvp-border-subtle',
              'text-tvp-text-secondary text-xs font-medium',
              'hover:border-tvp-accent-cyan hover:text-tvp-accent-cyan transition-colors'
            )}
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add to Set</span>
          </button>
          <button
            onClick={handleDownload}
            onMouseEnter={() => setIsDownloadHovered(true)}
            onMouseLeave={() => setIsDownloadHovered(false)}
            disabled={isDownloading}
            className={clsx(
              'relative flex items-center justify-center w-9 h-9 rounded-lg',
              'transition-colors',
              isAtLimit
                ? 'bg-tvp-bg-tertiary border border-tvp-status-error/30 text-tvp-status-error cursor-pointer'
                : isNearLimit
                ? 'bg-tvp-status-warning text-black hover:bg-tvp-status-warning/80'
                : 'bg-tvp-accent-cyan text-black hover:bg-tvp-accent-cyan-hover',
              isDownloading && 'opacity-50 cursor-wait'
            )}
            title={isAtLimit ? 'Download limit reached - Click to upgrade' : 'Download'}
          >
            {isAtLimit ? (
              <Lock className="w-4 h-4" />
            ) : (
              <Download className="w-4 h-4" />
            )}

            {/* Tooltip for limit reached */}
            {isAtLimit && isDownloadHovered && (
              <div
                className={clsx(
                  'absolute bottom-full right-0 mb-2',
                  'px-2 py-1 rounded',
                  'bg-tvp-bg-primary border border-tvp-border-default',
                  'text-xs text-tvp-status-error whitespace-nowrap',
                  'shadow-elevated z-10',
                  'animate-fade-in'
                )}
              >
                Limit reached
              </div>
            )}
          </button>

          {/* Context Menu Button */}
          <div className="relative" ref={contextMenuRef}>
            <button
              onClick={handleContextMenuClick}
              className={clsx(
                'flex items-center justify-center w-9 h-9 rounded-lg',
                'bg-tvp-bg-tertiary border border-tvp-border-subtle',
                'text-tvp-text-muted hover:text-tvp-text-primary hover:border-tvp-border-default',
                'transition-colors'
              )}
              title="More options"
            >
              <MoreHorizontal className="w-4 h-4" />
            </button>

            {/* Context Menu Dropdown */}
            {showContextMenu && (
              <div
                className={clsx(
                  'absolute right-0 bottom-full mb-2 z-50',
                  'w-44 py-1.5 rounded-lg',
                  'bg-tvp-bg-elevated border border-tvp-border-default',
                  'shadow-elevated animate-fade-in'
                )}
              >
                <button
                  onClick={handleAddToCrate}
                  className="w-full px-3 py-2 text-left text-sm text-tvp-text-secondary hover:text-tvp-text-primary hover:bg-tvp-bg-tertiary flex items-center gap-2"
                >
                  <FolderPlus className="w-4 h-4" />
                  Add to Crate
                </button>
                <button
                  onClick={handleShare}
                  className="w-full px-3 py-2 text-left text-sm text-tvp-text-secondary hover:text-tvp-text-primary hover:bg-tvp-bg-tertiary flex items-center gap-2"
                >
                  <Share2 className="w-4 h-4" />
                  Share
                </button>
                <button
                  onClick={handleViewDetails}
                  className="w-full px-3 py-2 text-left text-sm text-tvp-text-secondary hover:text-tvp-text-primary hover:bg-tvp-bg-tertiary flex items-center gap-2"
                >
                  <Eye className="w-4 h-4" />
                  View Details
                </button>
                <button
                  onClick={handleMoreLikeThis}
                  className="w-full px-3 py-2 text-left text-sm text-tvp-text-secondary hover:text-tvp-accent-cyan hover:bg-tvp-bg-tertiary flex items-center gap-2"
                >
                  <Sparkles className="w-4 h-4" />
                  More Like This
                </button>
                <div className="border-t border-tvp-border-subtle my-1" />
                <button
                  onClick={(e) => { e.stopPropagation(); setShowContextMenu(false); showToast('info', 'Report submitted'); }}
                  className="w-full px-3 py-2 text-left text-sm text-tvp-text-muted hover:text-tvp-status-error hover:bg-tvp-bg-tertiary flex items-center gap-2"
                >
                  <Flag className="w-4 h-4" />
                  Report Issue
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
