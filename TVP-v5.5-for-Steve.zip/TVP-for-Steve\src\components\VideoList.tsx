// ============================================
// THE VIDEO POOL - VIDEO LIST VIEW v5.5
// Spotify/iTunes style list with all metadata
// Auto-switches to virtualized rendering for large lists
// Responsive: hides columns on smaller screens
// ============================================

import { useState } from 'react';
import { Play, Plus, Download, Check, MoreHorizontal, Search, Heart } from 'lucide-react';
import { clsx } from 'clsx';
import { Track, VideoQuality } from '@/types';
import { useAppStore } from '@/stores/appStore';
import VirtualizedVideoList from './VirtualizedVideoList';

// Format download count
function formatDownloads(count: number): string {
  if (count >= 1000000) return `${(count / 1000000).toFixed(1)}M`;
  if (count >= 1000) return `${(count / 1000).toFixed(1)}K`;
  return count.toString();
}

interface VideoListProps {
  tracks: Track[];
  showHeader?: boolean;
  height?: number;
  virtualize?: boolean; // Force virtualization regardless of count
}

// Threshold for auto-virtualization (performance critical above this)
const VIRTUALIZATION_THRESHOLD = 100;

// Quality badge for list view
function QualityBadge({ quality }: { quality: VideoQuality }) {
  const qualityClasses: Record<VideoQuality, string> = {
    '4K': 'quality-4k',
    '1080p': 'quality-1080p',
    '720p': 'quality-720p',
    '480p': 'quality-480p',
    '320p': 'quality-320p',
  };

  return (
    <span
      className={clsx(
        'px-1.5 py-0.5 rounded text-[10px] font-bold text-center',
        qualityClasses[quality]
      )}
    >
      {quality}
    </span>
  );
}

// Responsive grid columns - hide less important columns on smaller screens
// Mobile: #, Preview+Artist, Title, Actions
// Tablet: + Label, BPM, Key, Quality
// Desktop: + Duration
// v5.5 Grid columns - Preview+Artist combined, Label after Title
const GRID_COLUMNS = {
  mobile: '32px 80px 1fr 80px',
  tablet: '36px 90px 2fr 90px 60px 50px 70px 80px', // Preview+Artist, Title, Label, BPM, Key, Quality, Actions
  desktop: '40px 100px 2fr 100px 70px 60px 70px 80px 120px', // + Duration
};

// Single list row
function VideoListItem({ track, index }: { track: Track; index: number }) {
  const [isHovered, setIsHovered] = useState(false);
  const [isFavorite, setIsFavorite] = useState(track.isFavorite ?? false);

  const {
    selectedTrackIds,
    toggleTrackSelection,
    openPreviewModal,
    addToSet,
    showToast,
  } = useAppStore();

  const isSelected = selectedTrackIds.has(track.id);

  const handleCheckboxClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleTrackSelection(track.id);
  };

  const handlePlay = (e: React.MouseEvent) => {
    e.stopPropagation();
    openPreviewModal(track.id);
  };

  const handleAddToSet = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToSet(track);
  };

  const handleDownload = (e: React.MouseEvent) => {
    e.stopPropagation();
    showToast('info', `Downloading "${track.title}"...`);
  };

  const handleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsFavorite(!isFavorite);
    showToast('success', isFavorite ? 'Removed from favorites' : 'Added to favorites');
  };

  return (
    <div
      onClick={() => openPreviewModal(track.id)}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className={clsx(
        'grid items-center gap-2 md:gap-3 px-2 md:px-4 py-2 md:py-2.5 rounded-lg cursor-pointer',
        'transition-all duration-fast',
        index % 2 === 0 ? 'bg-tvp-bg-primary' : 'bg-tvp-bg-secondary/50',
        isHovered && 'bg-tvp-bg-tertiary',
        isSelected && 'bg-tvp-accent-cyan-subtle',
        // v5.5 Responsive grid columns - Preview+Artist combined, Label after Title
        'grid-cols-[32px_80px_1fr_80px]',
        'md:grid-cols-[36px_90px_2fr_90px_60px_50px_70px_80px]',
        'lg:grid-cols-[40px_100px_2fr_100px_70px_60px_70px_80px_120px]'
      )}
    >
      {/* Checkbox / Number */}
      <div className="flex items-center justify-center">
        {isHovered || isSelected ? (
          <button
            onClick={handleCheckboxClick}
            className={clsx(
              'w-5 h-5 rounded border-2 flex items-center justify-center',
              'transition-colors',
              isSelected
                ? 'bg-tvp-accent-cyan border-tvp-accent-cyan'
                : 'border-tvp-border-default hover:border-tvp-accent-cyan'
            )}
            aria-label={isSelected ? 'Deselect track' : 'Select track'}
          >
            {isSelected && <Check className="w-3 h-3 text-black" />}
          </button>
        ) : (
          <span className="text-xs md:text-sm text-tvp-text-muted font-mono">
            {index + 1}
          </span>
        )}
      </div>

      {/* Preview + Artist Combined */}
      <div className="flex items-center gap-2">
        <div className="relative flex-shrink-0">
          <img
            src={track.thumbnailUrl || `https://picsum.photos/60/34?random=${track.id}`}
            alt=""
            className="w-[50px] h-[28px] md:w-[55px] md:h-[31px] lg:w-[60px] lg:h-[34px] rounded object-cover"
          />
          {isHovered && (
            <button
              onClick={handlePlay}
              className="absolute inset-0 flex items-center justify-center bg-black/60 rounded"
              aria-label={`Play ${track.title}`}
            >
              <Play className="w-4 h-4 text-white" fill="white" />
            </button>
          )}
        </div>
        <span className="text-xs md:text-sm text-tvp-text-secondary truncate">
          {track.artist}
        </span>
      </div>

      {/* Title + Badges (includes EXCLUSIVE) */}
      <div className="min-w-0">
        <div className="flex items-center gap-1 md:gap-2">
          <span className="text-xs md:text-sm font-medium text-tvp-text-primary truncate">
            {track.title}
          </span>
          {track.isExclusive && (
            <span className="hidden sm:inline px-1.5 py-0.5 text-[9px] font-bold bg-gradient-to-r from-yellow-500 to-amber-400 text-black rounded flex-shrink-0">
              EXCLUSIVE
            </span>
          )}
          {track.isNew && (
            <span className="hidden sm:inline px-1.5 py-0.5 text-[9px] font-bold bg-tvp-accent-coral text-white rounded flex-shrink-0">
              NEW
            </span>
          )}
          {track.isHot && (
            <span className="hidden sm:inline px-1.5 py-0.5 text-[9px] font-bold bg-gradient-to-r from-tvp-accent-coral to-tvp-status-warning text-white rounded flex-shrink-0">
              HOT
            </span>
          )}
        </div>
      </div>

      {/* Label - v5.5: Visible on tablet+, right after Title */}
      <div className="hidden md:block text-xs text-tvp-text-muted truncate">
        {track.label || '—'}
      </div>

      {/* BPM - Hidden on mobile */}
      <div className="hidden md:block text-sm font-mono text-tvp-text-muted text-center">
        {track.bpm}
      </div>

      {/* Key - Hidden on mobile */}
      <div className="hidden md:block text-sm font-mono text-tvp-accent-cyan text-center">
        {track.key}
      </div>

      {/* Quality - Hidden on mobile */}
      <div className="hidden md:flex justify-center">
        <QualityBadge quality={track.quality} />
      </div>

      {/* Duration - Hidden on mobile/tablet */}
      <div className="hidden lg:block text-sm font-mono text-tvp-text-muted text-center">
        {track.duration}
      </div>

      {/* Actions - with Heart/Favorite */}
      <div className="flex items-center justify-end gap-0.5 md:gap-1">
        <button
          onClick={handleFavorite}
          className={clsx(
            'p-1 md:p-1.5 rounded-md transition-colors',
            isFavorite
              ? 'text-tvp-accent-coral'
              : 'text-tvp-text-muted hover:text-tvp-accent-coral hover:bg-tvp-bg-elevated',
            isHovered || isFavorite ? 'opacity-100' : 'md:opacity-0'
          )}
          title={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
          aria-label={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
        >
          <Heart className="w-3.5 h-3.5 md:w-4 md:h-4" fill={isFavorite ? 'currentColor' : 'none'} />
        </button>
        <button
          onClick={handleAddToSet}
          className={clsx(
            'p-1 md:p-1.5 rounded-md transition-colors',
            'text-tvp-text-muted hover:text-tvp-accent-cyan hover:bg-tvp-bg-elevated',
            isHovered ? 'opacity-100' : 'md:opacity-0'
          )}
          title="Add to Set"
          aria-label="Add to set"
        >
          <Plus className="w-3.5 h-3.5 md:w-4 md:h-4" />
        </button>
        <button
          onClick={handleDownload}
          className={clsx(
            'p-1 md:p-1.5 rounded-md transition-colors',
            'text-tvp-text-muted hover:text-tvp-accent-cyan hover:bg-tvp-bg-elevated',
            isHovered ? 'opacity-100' : 'md:opacity-0'
          )}
          title="Download"
          aria-label="Download"
        >
          <Download className="w-3.5 h-3.5 md:w-4 md:h-4" />
        </button>
        <button
          onClick={(e) => e.stopPropagation()}
          className={clsx(
            'hidden md:block p-1.5 rounded-md transition-colors',
            'text-tvp-text-muted hover:text-tvp-text-primary hover:bg-tvp-bg-elevated',
            isHovered ? 'opacity-100' : 'opacity-0'
          )}
          title="More options"
          aria-label="More options"
        >
          <MoreHorizontal className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

// Main list component - auto-virtualizes for large lists
export default function VideoList({
  tracks,
  showHeader = true,
  height,
  virtualize,
}: VideoListProps) {
  // Use virtualization for large lists or when forced
  const shouldVirtualize = virtualize || tracks.length > VIRTUALIZATION_THRESHOLD;

  if (shouldVirtualize) {
    return (
      <VirtualizedVideoList
        tracks={tracks}
        showHeader={showHeader}
        height={height}
      />
    );
  }

  // Empty state
  if (tracks.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <div className="w-16 h-16 rounded-full bg-tvp-bg-tertiary flex items-center justify-center mb-4">
          <Search className="w-8 h-8 text-tvp-text-muted" />
        </div>
        <h3 className="text-lg font-medium text-tvp-text-primary mb-2">
          No videos found
        </h3>
        <p className="text-tvp-text-secondary max-w-md">
          Try adjusting your filters or search terms
        </p>
      </div>
    );
  }

  // Standard rendering for small lists (better for sections with few items)
  return (
    <div className="w-full overflow-x-auto">
      {/* Header Row - Responsive */}
      {showHeader && (
        <div
          className={clsx(
            'grid items-center gap-2 md:gap-3 px-2 md:px-4 py-2 md:py-3 border-b border-tvp-border-subtle',
            'text-[10px] md:text-xs font-semibold text-tvp-text-muted uppercase tracking-wider',
            'grid-cols-[32px_80px_1fr_80px]',
            'md:grid-cols-[36px_90px_2fr_90px_60px_50px_70px_80px]',
            'lg:grid-cols-[40px_100px_2fr_100px_70px_60px_70px_80px_120px]'
          )}
        >
          <div className="text-center">#</div>
          <div>Preview / Artist</div>
          <div>Title</div>
          <div className="hidden md:block">Label</div>
          <div className="hidden md:block text-center">BPM</div>
          <div className="hidden md:block text-center">Key</div>
          <div className="hidden md:block text-center">Quality</div>
          <div className="hidden lg:block text-center">Duration</div>
          <div className="text-right">Actions</div>
        </div>
      )}

      {/* Track Rows */}
      <div className="divide-y divide-tvp-border-subtle/50">
        {tracks.map((track, index) => (
          <VideoListItem key={track.id} track={track} index={index} />
        ))}
      </div>
    </div>
  );
}
