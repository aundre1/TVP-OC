// ============================================
// THE VIDEO POOL - MAIN APP COMPONENT
// ============================================

import { useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { useUIStore } from '@/stores/uiStore';

// Layout - Using v5.5 layout with all panels and modals
import Layout from '@/components/LayoutV2';

// Pages
import LandingPage from '@/pages/LandingPage';
import HomePage from '@/pages/HomePageV2';
import LoginPage from '@/pages/LoginPage';
import RegisterPage from '@/pages/RegisterPage';
import ForgotPasswordPage from '@/pages/ForgotPasswordPage';
import ResetPasswordPage from '@/pages/ResetPasswordPage';
import EmailVerificationPage from '@/pages/EmailVerificationPage';
import VideoPage from '@/pages/VideoPage';
import SearchPage from '@/pages/SearchPage';
import LibraryPage from '@/pages/LibraryPage';
import DownloadsPage from '@/pages/DownloadsPage';
import MembershipPage from '@/pages/MembershipPage';
import MembershipSuccessPage from '@/pages/MembershipSuccessPage';
import SettingsPage from '@/pages/SettingsPage';
import AdminPage from '@/pages/AdminPage';
import InsightsPage from '@/pages/InsightsPage';
import SharedSetPage from '@/pages/SharedSetPage';

// Loading spinner
function LoadingScreen() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-tvp-bg-primary">
      <div className="flex flex-col items-center gap-4">
        <div className="w-12 h-12 border-4 border-tvp-accent-cyan border-t-transparent rounded-full animate-spin" />
        <span className="text-tvp-text-secondary">Loading...</span>
      </div>
    </div>
  );
}

// Protected route wrapper - redirects to landing page if not authenticated
function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return <LoadingScreen />;
  }

  if (!isAuthenticated) {
    return <Navigate to="/welcome" replace />;
  }

  return <>{children}</>;
}

// Public route wrapper - shows landing page for non-authenticated users
function PublicLandingRoute() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return <LoadingScreen />;
  }

  // If already authenticated, redirect to dashboard
  if (isAuthenticated) {
    return <Navigate to="/home" replace />;
  }

  return <LandingPage />;
}

// Root redirect - sends to /home if authenticated, /welcome if not
function RootRedirect() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return <LoadingScreen />;
  }

  return <Navigate to={isAuthenticated ? '/home' : '/welcome'} replace />;
}

// Auth route wrapper (redirect if already logged in)
function AuthRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return <LoadingScreen />;
  }

  if (isAuthenticated) {
    return <Navigate to="/home" replace />;
  }

  return <>{children}</>;
}

export default function App() {
  const { isLoading } = useAuth();
  const { theme } = useUIStore();

  // Apply theme class to document
  useEffect(() => {
    document.documentElement.classList.toggle('light', theme === 'light');
  }, [theme]);

  if (isLoading) {
    return <LoadingScreen />;
  }

  return (
    <Routes>
      {/* Public landing page - shown to non-authenticated visitors */}
      <Route path="/welcome" element={<PublicLandingRoute />} />

      {/* Root redirects based on auth status */}
      <Route path="/" element={<RootRedirect />} />

      {/* Auth routes */}
      <Route
        path="/login"
        element={
          <AuthRoute>
            <LoginPage />
          </AuthRoute>
        }
      />
      <Route
        path="/register"
        element={
          <AuthRoute>
            <RegisterPage />
          </AuthRoute>
        }
      />
      <Route
        path="/forgot-password"
        element={
          <AuthRoute>
            <ForgotPasswordPage />
          </AuthRoute>
        }
      />
      <Route
        path="/reset-password"
        element={
          <AuthRoute>
            <ResetPasswordPage />
          </AuthRoute>
        }
      />
      <Route
        path="/verify-email"
        element={<EmailVerificationPage />}
      />

      {/* Public shared set page (no auth required) */}
      <Route path="/set/:shareId" element={<SharedSetPage />} />

      {/* Main app routes (protected) */}
      <Route
        path="/home"
        element={
          <ProtectedRoute>
            <Layout />
          </ProtectedRoute>
        }
      >
        <Route index element={<HomePage />} />
      </Route>

      <Route
        element={
          <ProtectedRoute>
            <Layout />
          </ProtectedRoute>
        }
      >
        <Route path="video/:id" element={<VideoPage />} />
        <Route path="search" element={<SearchPage />} />
        <Route path="library" element={<LibraryPage />} />
        <Route path="downloads" element={<DownloadsPage />} />
        <Route path="membership" element={<MembershipPage />} />
        <Route path="membership/success" element={<MembershipSuccessPage />} />
        <Route path="settings" element={<SettingsPage />} />
        <Route path="admin" element={<AdminPage />} />
        <Route path="insights" element={<InsightsPage />} />
      </Route>

      {/* Catch all - redirect to welcome/landing page */}
      <Route path="*" element={<Navigate to="/welcome" replace />} />
    </Routes>
  );
}
