// ============================================
// THE VIDEO POOL - PREVIEW MODAL v5.5
// With version dropdowns, quality selection,
// and file size estimates
// ============================================

import { useState } from 'react';
import { createPortal } from 'react-dom';
import {
  X,
  Play,
  Pause,
  Download,
  Plus,
  ChevronDown,
  Volume2,
  Maximize2,
  SkipBack,
  SkipForward,
  Lock,
  AlertCircle,
  Sparkles,
  Heart,
} from 'lucide-react';
import { clsx } from 'clsx';
import { useAppStore } from '@/stores/appStore';
import { getTrackById } from '@/data/tracks';
import { useDownloadWithLimitCheck } from '@/hooks';
import { VersionType, VideoQuality } from '@/types';

// Version types available
const VERSION_TYPES: VersionType[] = ['Clean', 'Explicit', 'Intro', 'Outro', 'Quick Hit', 'Xtendz'];

// Quality options
const VIDEO_QUALITIES: { value: VideoQuality; label: string; size: string }[] = [
  { value: '4K', label: '4K Ultra HD', size: '~2.5 GB' },
  { value: '1080p', label: '1080p Full HD', size: '~800 MB' },
  { value: '720p', label: '720p HD', size: '~400 MB' },
];

const AUDIO_QUALITIES: { value: string; label: string; size: string }[] = [
  { value: '320', label: '320 kbps', size: '~12 MB' },
  { value: '192', label: '192 kbps', size: '~8 MB' },
];

export default function PreviewModal() {
  const {
    isPreviewModalOpen,
    previewTrackId,
    closePreviewModal,
    addToSet,
    showToast,
    openDownloadQualityModal,
  } = useAppStore();

  const {
    canDownload,
    isAtLimit,
    isNearLimit,
    downloadsRemaining,
    isDownloading,
    openDownloadLimitModal,
  } = useDownloadWithLimitCheck();

  const [isPlaying, setIsPlaying] = useState(false);
  const [selectedVersion, setSelectedVersion] = useState<VersionType>('Clean');
  const [videoQuality, setVideoQuality] = useState<VideoQuality>('1080p');
  const [audioQuality, setAudioQuality] = useState('320');
  const [showVersions, setShowVersions] = useState(false);

  const track = previewTrackId ? getTrackById(previewTrackId) : null;

  if (!isPreviewModalOpen || !track) return null;

  const handleDownload = () => {
    // Check if at download limit
    if (isAtLimit || !canDownload) {
      openDownloadLimitModal();
      return;
    }

    // Open quality selection modal (closes preview modal first)
    closePreviewModal();
    openDownloadQualityModal(track.id);
  };

  const handleAddToSet = () => {
    addToSet(track);
  };

  // Simulate available versions (in production, this would come from API)
  const availableVersions = VERSION_TYPES.slice(0, Math.min(track.id % 4 + 2, 6));

  return createPortal(
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-sm z-500"
        onClick={closePreviewModal}
      />

      {/* Modal */}
      <div
        className={clsx(
          'fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2',
          'w-[900px] max-w-[95vw] max-h-[90vh]',
          'bg-tvp-bg-secondary border border-tvp-border-default rounded-2xl',
          'shadow-elevated z-500 overflow-hidden',
          'flex flex-col',
          'animate-fade-in'
        )}
      >
        {/* Video Player Area */}
        <div
          className={clsx(
            'relative bg-black',
            track.aspect === '4:3' ? 'aspect-[4/3]' : 'aspect-video'
          )}
        >
          {/* Video Thumbnail (placeholder for actual video) */}
          <img
            src={`https://picsum.photos/900/506?random=${track.id}`}
            alt={track.title}
            className="w-full h-full object-contain"
          />

          {/* Play Overlay */}
          <div className="absolute inset-0 flex items-center justify-center bg-black/40">
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className={clsx(
                'w-20 h-20 rounded-full',
                'bg-tvp-accent-cyan/90 hover:bg-tvp-accent-cyan',
                'flex items-center justify-center',
                'transition-transform hover:scale-105'
              )}
            >
              {isPlaying ? (
                <Pause className="w-8 h-8 text-black" fill="black" />
              ) : (
                <Play className="w-8 h-8 text-black ml-1" fill="black" />
              )}
            </button>
          </div>

          {/* Close Button */}
          <button
            onClick={closePreviewModal}
            className="absolute top-4 right-4 p-2 rounded-lg bg-black/60 hover:bg-black/80 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Video Controls */}
          <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/90 to-transparent">
            {/* Progress Bar */}
            <div className="w-full h-1 bg-white/20 rounded-full mb-3 cursor-pointer">
              <div className="w-1/3 h-full bg-tvp-accent-cyan rounded-full" />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <button className="text-white/70 hover:text-white transition-colors">
                  <SkipBack className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="text-white hover:text-tvp-accent-cyan transition-colors"
                >
                  {isPlaying ? (
                    <Pause className="w-6 h-6" />
                  ) : (
                    <Play className="w-6 h-6" />
                  )}
                </button>
                <button className="text-white/70 hover:text-white transition-colors">
                  <SkipForward className="w-5 h-5" />
                </button>
                <span className="text-sm text-white/70 font-mono">
                  1:23 / {track.duration}
                </span>
              </div>

              <div className="flex items-center gap-3">
                <button className="text-white/70 hover:text-white transition-colors">
                  <Volume2 className="w-5 h-5" />
                </button>
                <button className="text-white/70 hover:text-white transition-colors">
                  <Maximize2 className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Info & Actions */}
        <div className="p-6">
          {/* Track Info - v5.5: Artist | Title | Label inline format */}
          <div className="mb-6">
            {/* Main Title Row: Artist | Title | Label */}
            <div className="flex items-center gap-3 mb-2">
              <span className="text-lg text-tvp-text-secondary font-medium flex-shrink-0">
                {track.artist}
              </span>
              <span className="text-tvp-border-subtle text-lg">|</span>
              <h2 className="text-xl font-bold text-tvp-text-primary">
                {track.title}
              </h2>
              {track.label && (
                <>
                  <span className="text-tvp-border-subtle text-lg">|</span>
                  <span className="text-sm text-tvp-text-muted">
                    {track.label}
                  </span>
                </>
              )}
              {/* Genre Badge */}
              <span className="ml-auto px-3 py-1.5 bg-tvp-bg-tertiary rounded-lg text-sm text-tvp-text-secondary flex-shrink-0">
                {track.subgenre || track.genre}
              </span>
            </div>

            {/* Metadata Row: BPM, Key, Duration */}
            <div className="flex items-center gap-3 text-sm font-mono text-tvp-text-muted">
              <span>{track.bpm} BPM</span>
              <span className="text-tvp-border-default">|</span>
              <span className="text-tvp-accent-cyan">{track.key}</span>
              <span className="text-tvp-border-default">|</span>
              <span>{track.duration}</span>
              <span className="text-tvp-border-default">|</span>
              <span>{track.quality}</span>
            </div>
          </div>

          {/* Version Selection */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-semibold text-tvp-text-secondary">
                Available Versions
              </span>
              <button
                onClick={() => setShowVersions(!showVersions)}
                className="text-xs text-tvp-accent-cyan hover:underline"
              >
                {showVersions ? 'Show less' : `Show all ${availableVersions.length}`}
              </button>
            </div>

            <div className="flex flex-wrap gap-2">
              {(showVersions ? availableVersions : availableVersions.slice(0, 2)).map(
                (version) => (
                  <button
                    key={version}
                    onClick={() => setSelectedVersion(version)}
                    className={clsx(
                      'px-4 py-2 rounded-lg text-sm font-medium',
                      'border transition-all duration-fast',
                      selectedVersion === version
                        ? 'bg-tvp-accent-cyan border-tvp-accent-cyan text-black'
                        : 'bg-tvp-bg-tertiary border-tvp-border-subtle text-tvp-text-secondary hover:border-tvp-accent-cyan'
                    )}
                  >
                    {version}
                  </button>
                )
              )}
            </div>
          </div>

          {/* Quality Selection */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            {/* Video Quality */}
            <div>
              <label className="text-sm font-semibold text-tvp-text-secondary mb-2 block">
                Video Quality
              </label>
              <div className="relative">
                <select
                  value={videoQuality}
                  onChange={(e) => setVideoQuality(e.target.value as VideoQuality)}
                  className={clsx(
                    'w-full px-4 py-3 rounded-lg appearance-none',
                    'bg-tvp-bg-tertiary border border-tvp-border-default',
                    'text-tvp-text-primary text-sm',
                    'focus:border-tvp-accent-cyan focus:outline-none',
                    'cursor-pointer'
                  )}
                >
                  {VIDEO_QUALITIES.map((q) => (
                    <option key={q.value} value={q.value}>
                      {q.label} ({q.size})
                    </option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-tvp-text-muted pointer-events-none" />
              </div>
            </div>

            {/* Audio Quality */}
            <div>
              <label className="text-sm font-semibold text-tvp-text-secondary mb-2 block">
                Audio Quality
              </label>
              <div className="relative">
                <select
                  value={audioQuality}
                  onChange={(e) => setAudioQuality(e.target.value)}
                  className={clsx(
                    'w-full px-4 py-3 rounded-lg appearance-none',
                    'bg-tvp-bg-tertiary border border-tvp-border-default',
                    'text-tvp-text-primary text-sm',
                    'focus:border-tvp-accent-cyan focus:outline-none',
                    'cursor-pointer'
                  )}
                >
                  {AUDIO_QUALITIES.map((q) => (
                    <option key={q.value} value={q.value}>
                      {q.label} ({q.size})
                    </option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-tvp-text-muted pointer-events-none" />
              </div>
            </div>
          </div>

          {/* Download Limit Warning */}
          {isNearLimit && !isAtLimit && (
            <div className="mb-4 flex items-center gap-2 px-3 py-2 rounded-lg bg-tvp-status-warning/10 border border-tvp-status-warning/30">
              <AlertCircle className="w-4 h-4 text-tvp-status-warning flex-shrink-0" />
              <span className="text-sm text-tvp-status-warning">
                {downloadsRemaining === 'unlimited'
                  ? 'Unlimited downloads'
                  : `Only ${downloadsRemaining} downloads remaining this month`}
              </span>
            </div>
          )}

          {isAtLimit && (
            <div className="mb-4 flex items-center gap-2 px-3 py-2 rounded-lg bg-tvp-status-error/10 border border-tvp-status-error/30">
              <Lock className="w-4 h-4 text-tvp-status-error flex-shrink-0" />
              <span className="text-sm text-tvp-status-error">
                Download limit reached. Upgrade to continue downloading.
              </span>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-3">
            <button
              onClick={handleAddToSet}
              className={clsx(
                'flex-1 flex items-center justify-center gap-2 py-3.5 rounded-lg',
                'bg-tvp-bg-tertiary border border-tvp-border-subtle',
                'text-tvp-text-secondary font-medium',
                'hover:border-tvp-accent-cyan hover:text-tvp-accent-cyan transition-colors'
              )}
            >
              <Plus className="w-5 h-5" />
              <span>Add to Set</span>
            </button>
            <button
              onClick={() => {
                closePreviewModal();
                showToast('info', `Finding tracks similar to "${track.title}"...`);
              }}
              className={clsx(
                'flex items-center justify-center gap-2 px-4 py-3.5 rounded-lg',
                'bg-tvp-bg-tertiary border border-tvp-border-subtle',
                'text-tvp-text-secondary font-medium',
                'hover:border-tvp-accent-cyan hover:text-tvp-accent-cyan transition-colors'
              )}
              title="Find similar tracks"
            >
              <Sparkles className="w-5 h-5" />
            </button>
            <button
              onClick={handleDownload}
              disabled={isDownloading}
              className={clsx(
                'flex-[2] flex items-center justify-center gap-2 py-3.5 rounded-lg',
                'font-semibold transition-colors',
                isAtLimit
                  ? 'bg-tvp-status-error/10 border border-tvp-status-error/30 text-tvp-status-error hover:bg-tvp-status-error/20'
                  : isNearLimit
                  ? 'bg-tvp-status-warning text-black hover:bg-tvp-status-warning/80'
                  : 'bg-tvp-accent-cyan text-black hover:bg-tvp-accent-cyan-hover',
                isDownloading && 'opacity-50 cursor-wait'
              )}
            >
              {isAtLimit ? (
                <>
                  <Lock className="w-5 h-5" />
                  <span>Upgrade to Download</span>
                </>
              ) : (
                <>
                  <Download className="w-5 h-5" />
                  <span>Download {selectedVersion}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </>,
    document.body
  );
}
